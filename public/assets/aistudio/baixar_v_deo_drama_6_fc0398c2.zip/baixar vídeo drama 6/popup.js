document.addEventListener("DOMContentLoaded", () => {
  const elements = {
    btnRefresh: document.getElementById("btn-refresh"),
    inputManualUrl: document.getElementById("input-manual-url"),
    btnAddManual: document.getElementById("btn-add-manual"),
    stateLoading: document.getElementById("state-loading"),
    stateEmpty: document.getElementById("state-empty"),
    stateError: document.getElementById("state-error"),
    stateList: document.getElementById("state-list"),
    videoItemsList: document.getElementById("video-items-list"),
    errorMessage: document.getElementById("error-message")
  };

  let videoListStore = [];

  function showState(targetState) {
    [elements.stateLoading, elements.stateEmpty, elements.stateError, elements.stateList].forEach(el => {
      if (el) el.classList.add("state-hidden");
    });
    if (targetState) targetState.classList.remove("state-hidden");
  }

  function copyToClipboard(text, buttonEl) {
    navigator.clipboard.writeText(text).then(() => {
      const originalText = buttonEl.textContent;
      buttonEl.textContent = "✓ Copiado!";
      setTimeout(() => {
        buttonEl.textContent = originalText;
      }, 2000);
    });
  }

  function detectFormat(url) {
    const lower = url.toLowerCase();
    if (lower.includes(".m3u8")) return "M3U8 (HLS)";
    if (lower.includes(".mp4")) return "MP4";
    return "LINK VÍDEO";
  }

  function createVideoCard(video) {
    const card = document.createElement("div");
    card.className = "video-card";

    const header = document.createElement("div");
    header.className = "card-header";

    const title = document.createElement("p");
    title.className = "video-title";
    title.textContent = video.title || "Vídeo Encontrado";

    const badge = document.createElement("span");
    badge.className = video.isHls ? "badge-hls" : "badge-mp4";
    badge.textContent = video.format;

    header.appendChild(title);
    header.appendChild(badge);

    const previewWrapper = document.createElement("div");
    previewWrapper.className = "video-preview";

    const player = document.createElement("video");
    player.controls = true;
    player.preload = "metadata";
    player.src = video.url;

    previewWrapper.appendChild(player);

    const urlBox = document.createElement("div");
    urlBox.className = "card-url-box";

    const urlInput = document.createElement("input");
    urlInput.className = "card-url-input";
    urlInput.type = "text";
    urlInput.readOnly = true;
    urlInput.value = video.url;

    const btnCopy = document.createElement("button");
    btnCopy.className = "btn-secondary";
    btnCopy.textContent = "📋 Copiar";
    btnCopy.addEventListener("click", () => copyToClipboard(video.url, btnCopy));

    urlBox.appendChild(urlInput);
    urlBox.appendChild(btnCopy);

    const actions = document.createElement("div");
    actions.className = "card-actions";

    const btnDownload = document.createElement("button");
    btnDownload.className = "btn-primary";

    if (video.isHls) {
      btnDownload.textContent = "⚡ Baixar (HLS Web)";
      btnDownload.addEventListener("click", () => {
        window.open(`https://m3u8-downloader.com/?url=${encodeURIComponent(video.url)}`, "_blank");
      });
    } else {
      btnDownload.textContent = "⬇ Baixar MP4";
      btnDownload.addEventListener("click", () => {
        chrome.runtime.sendMessage({
          action: "downloadVideo",
          url: video.url,
          filename: "dorama_video.mp4"
        });
      });
    }

    const btnOpen = document.createElement("button");
    btnOpen.className = "btn-secondary";
    btnOpen.textContent = "🔗 Abrir em Nova Aba";
    btnOpen.addEventListener("click", () => window.open(video.url, "_blank"));

    actions.appendChild(btnDownload);
    actions.appendChild(btnOpen);

    card.appendChild(header);
    card.appendChild(previewWrapper);
    card.appendChild(urlBox);
    card.appendChild(actions);

    return card;
  }

  function renderVideoList(videos) {
    if (!elements.videoItemsList) return;
    elements.videoItemsList.textContent = "";

    if (!videos || videos.length === 0) {
      showState(elements.stateEmpty);
      return;
    }

    videos.forEach(video => {
      const card = createVideoCard(video);
      elements.videoItemsList.appendChild(card);
    });

    showState(elements.stateList);
  }

  async function handleAddManualUrl() {
    const rawUrl = elements.inputManualUrl.value.trim();
    if (!rawUrl) return;

    const lowerUrl = rawUrl.toLowerCase();
    const isDirectVideo = lowerUrl.includes(".mp4") || lowerUrl.includes(".m3u8");

    if (isDirectVideo) {
      const isHls = lowerUrl.includes(".m3u8");
      const newVideo = {
        id: "manual_" + Date.now(),
        url: rawUrl,
        title: "Link de Vídeo Direto",
        format: detectFormat(rawUrl),
        isHls: isHls,
        timestamp: Date.now()
      };

      videoListStore = [newVideo, ...videoListStore];
      elements.inputManualUrl.value = "";
      renderVideoList(videoListStore);
    } else {
      showState(elements.stateLoading);
      try {
        const response = await fetch(rawUrl);
        const htmlText = await response.text();

        const videoRegex = /https?:\/\/[^"'\s]+\.(?:mp4|m3u8)[^"'\s]*/gi;
        const matches = htmlText.match(videoRegex) || [];
        const uniqueLinks = [...new Set(matches)];

        if (uniqueLinks.length > 0) {
          const extractedVideos = uniqueLinks.map((url, idx) => ({
            id: "extracted_" + Date.now() + "_" + idx,
            url: url,
            title: `Vídeo Extraído (${idx + 1})`,
            format: detectFormat(url),
            isHls: url.toLowerCase().includes(".m3u8"),
            timestamp: Date.now()
          }));

          videoListStore = [...extractedVideos, ...videoListStore];
          elements.inputManualUrl.value = "";
          renderVideoList(videoListStore);
        } else {
          chrome.tabs.create({ url: rawUrl, active: true });
        }
      } catch (err) {
        chrome.tabs.create({ url: rawUrl, active: true });
      }
    }
  }

  function fetchVideos() {
    showState(elements.stateLoading);

    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs || tabs.length === 0) {
        showState(elements.stateError);
        return;
      }

      const activeTabId = tabs[0].id;

      chrome.runtime.sendMessage({ action: "getVideos", tabId: activeTabId }, response => {
        if (chrome.runtime.lastError || !response) {
          showState(elements.stateError);
          return;
        }

        videoListStore = response.videos || [];
        renderVideoList(videoListStore);
      });
    });
  }

  if (elements.btnAddManual) {
    elements.btnAddManual.addEventListener("click", handleAddManualUrl);
  }

  if (elements.inputManualUrl) {
    elements.inputManualUrl.addEventListener("keypress", (e) => {
      if (e.key === "Enter") handleAddManualUrl();
    });
  }

  if (elements.btnRefresh) {
    elements.btnRefresh.addEventListener("click", fetchVideos);
  }

  fetchVideos();
});