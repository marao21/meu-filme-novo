"""Movie and streaming integrations."""
