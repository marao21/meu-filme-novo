"""Movie and streaming integrations."""
