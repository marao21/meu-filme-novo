from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import TvVideoSource

from ..extractors import (
    premium_player_extractor,
    watch_play_player_extractor,
    vip_player_player_extractor,
)

EXTRACTORS = {
    "Premium": premium_player_extractor.PremiumPlayerExtractor(),
    "WatchPlay": watch_play_player_extractor.WatchPlayPlayerExtractor(),
    "VIP Player": vip_player_player_extractor.VipPlayerPlayerExtractor(),
}


@dataclass
class TvPlayer:
    id: str
    title: str
    tv_id: str
    season: str
    episode: str
    release_date: str
    label: str
    embed: str
    lang: str
    budget: str
    icon: str
    embed_id: str | None = None

    def get_stream(self) -> TvVideoSource:
        extractor = EXTRACTORS.get(self.label)
        if not extractor:
            raise NotImplementedError(
                f"[PLAYERFLIX TV] nenhum extrator disponivel para o player : {self.label}"
            )

        return extractor.extract(self)
