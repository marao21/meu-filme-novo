﻿import os
from embed_movies.streaming.clients import PlayerFlixClient

token = "fb362501c06a4f4a286ed80b6073283a"
movie_id = "294254"

print(f"Buscando players para o ID {movie_id}...")
players = PlayerFlixClient.get_available_players_movie(movie_id)

if not players:
    print("Nenhum player disponivel no momento.")
else:
    for player in players:
        print(f"\nTestando Player: {player.label}...")
        try:
            stream = player.get_stream()
            link = stream.videoSource
            print("SUCESSO! Link encontrado:")
            print(link)
            
            import subprocess
            subprocess.run("clip", input=link.encode("utf-8"), check=True)
            print("(O link foi copiado para a sua area de transferencia! Cole no VLC ou no navegador)")
            break
        except Exception as err:
            print(f" -> Indisponivel neste player: {err}")